# GST Analysis System

A comprehensive hierarchical GST data analysis solution for detecting bogus transactions and analyzing purchase-sales relationships in GST networks.

## 🚀 Features

- **Hierarchical Analysis**: Build and analyze complex purchase hierarchies
- **Bogus Detection**: Identify potentially fraudulent transactions and entities
- **Interactive Web Interface**: Modern web-based dashboard for data exploration
- **Visual DAG Representation**: Directed Acyclic Graph visualization of relationships
- **Sales Record Analysis**: Detailed sales transaction analysis with color coding
- **Contamination Analysis**: Track contamination spread through the network
- **Export Capabilities**: Generate comprehensive reports and exports

## 📋 Requirements

- **Python**: 3.8 or higher
- **Operating System**: Windows, macOS, or Linux
- **Memory**: Minimum 4GB RAM (8GB recommended for large datasets)
- **Storage**: At least 1GB free space

## 🛠️ Installation

### Option 1: Quick Installation (Recommended)

#### For Linux/macOS:
```bash
# Clone or download the project
git clone <repository-url>
cd gst-analysis-final

# Run the installation script
chmod +x install.sh
./install.sh
```

#### For Windows:
```cmd
REM Download and extract the project
cd gst-analysis-final

REM Run the installation script
install.bat
```

### Option 2: Manual Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd gst-analysis-final
   ```

2. **Create virtual environment**:
   ```bash
   python -m venv venv
   
   # Activate (Linux/macOS)
   source venv/bin/activate
   
   # Activate (Windows)
   venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   pip install -e .
   ```

4. **Create directories**:
   ```bash
   mkdir -p data/input data/output logs reports
   ```

### Option 3: Docker Installation

1. **Using Docker Compose** (Recommended):
   ```bash
   docker-compose up -d
   ```

2. **Using Docker directly**:
   ```bash
   docker build -t gst-analysis .
   docker run -p 8000:8000 -v $(pwd)/data:/app/data gst-analysis
   ```

## ⚙️ Configuration

1. **Copy the example configuration**:
   ```bash
   cp config/settings.example.yaml config/settings.yaml
   ```

2. **Edit the configuration file** with your specific settings:
   ```yaml
   # Example configuration
   input_directory: "data/input"
   output_directory: "data/output"
   root_node_pan: "AAYCA4390A"  # Your root entity PAN
   ```

## 📊 Usage

### 1. Prepare Your Data

Place your GST data files in the `data/input/` directory:
- **gst_table_data.xlsx**: Main GST transaction data
- **sales_records.xlsx**: Sales transaction records
- **entity_master.xlsx**: Entity master data (optional)

### 2. Run Analysis

```bash
# Activate virtual environment (if not already active)
source venv/bin/activate  # Linux/macOS
# or
venv\Scripts\activate     # Windows

# Run the analysis
gst-analyze

# Or run directly
python scripts/run_analysis.py
```

### 3. Start Web Server

```bash
# Start the web server
gst-server

# Or run directly
python scripts/start_server.py
```

### 4. Access Web Interface

Open your browser and navigate to:
- **Main Interface**: http://localhost:8000
- **Hierarchy View**: http://localhost:8000/hierarchy
- **DAG View**: http://localhost:8000/dag

## 🎯 Key Features Guide

### Hierarchy Analysis
- **Interactive Tree View**: Expand/collapse nodes to explore the hierarchy
- **Color Coding**: 
  - 🔴 Red: Bogus entities
  - 🟡 Yellow: Contaminated entities  
  - 🟢 Green: Clean entities
- **Metrics Display**: View purchases, sales, and contamination levels

### Sales Record Analysis
- **Color-Coded Records**: Sales records are colored based on seller entity status
- **Search & Filter**: Find specific transactions or entities
- **Detailed Views**: Click "Show Sales" to see detailed transaction records

### DAG Visualization
- **Network View**: See the complete network structure
- **Interactive Navigation**: Click nodes to explore connections
- **Layout Options**: Different visualization layouts available

## 📁 Project Structure

```
gst-analysis-final/
├── src/                    # Source code
│   ├── analysis/          # Analysis modules
│   ├── config/            # Configuration management
│   ├── utils/             # Utility functions
│   └── web/               # Web application
├── scripts/               # Executable scripts
├── config/                # Configuration files
├── data/                  # Data directories
│   ├── input/            # Input data files
│   └── output/           # Generated outputs
├── logs/                  # Log files
├── reports/               # Generated reports
├── docs/                  # Documentation
└── tests/                 # Test files
```

## 🔧 Command Line Tools

After installation, these commands are available:

- `gst-analyze`: Run the complete analysis pipeline
- `gst-server`: Start the web server
- `gst-reports`: Generate reports

## 🐛 Troubleshooting

### Common Issues

1. **Python Version Error**:
   - Ensure Python 3.8+ is installed
   - Use `python3` instead of `python` on some systems

2. **Permission Errors**:
   - On Linux/macOS: `chmod +x install.sh`
   - Run as administrator on Windows if needed

3. **Port Already in Use**:
   - Change the port in `config/settings.yaml`
   - Or kill the process using port 8000

4. **Memory Issues**:
   - Reduce dataset size for testing
   - Increase system memory if possible

### Health Check

Run the health check to verify installation:
```bash
python scripts/health_check.py
```

## 📈 Performance Tips

- **Large Datasets**: Use chunked processing for files >100MB
- **Memory Usage**: Monitor memory usage with large hierarchies
- **Web Performance**: Use modern browsers for best performance

## 🔒 Security Notes

- **Data Privacy**: Ensure sensitive GST data is properly secured
- **Network Access**: Web server runs on localhost by default
- **File Permissions**: Set appropriate file permissions for data directories

## 📝 Data Format Requirements

### GST Table Data (gst_table_data.xlsx)
Required columns:
- `PAN`: Entity PAN number
- `Entity_Name`: Entity name
- `Total_Purchases`: Purchase amount
- `Total_Sales`: Sales amount
- `Parent_PAN`: Parent entity PAN (for hierarchy)

### Sales Records (sales_records.xlsx)
Required columns:
- `seller_pan`: Seller PAN
- `buyer_pan`: Buyer PAN
- `amount`: Transaction amount
- `buyer_name`: Buyer name (optional)

## 🤝 Support

For issues and questions:
1. Check the troubleshooting section above
2. Review the logs in the `logs/` directory
3. Run the health check script
4. Check the documentation in `docs/`

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Built with Flask, Pandas, and modern web technologies
- Designed for GST compliance and fraud detection
- Optimized for large-scale data analysis

---

**Version**: 1.0.0  
**Last Updated**: October 2025
