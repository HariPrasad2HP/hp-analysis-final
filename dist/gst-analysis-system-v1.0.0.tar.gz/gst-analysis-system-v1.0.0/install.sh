#!/bin/bash

# GST Analysis System - Installation Script
# This script sets up the GST Analysis System on Unix-like systems (Linux/macOS)

set -e  # Exit on any error

echo "🚀 GST Analysis System - Installation Script"
echo "============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Python 3.8+ is installed
check_python() {
    print_status "Checking Python installation..."
    
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
        PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
        PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
        
        if [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -ge 8 ]; then
            print_success "Python $PYTHON_VERSION found"
            return 0
        else
            print_error "Python 3.8+ required, found $PYTHON_VERSION"
            return 1
        fi
    else
        print_error "Python 3 not found. Please install Python 3.8 or higher."
        return 1
    fi
}

# Check if pip is installed
check_pip() {
    print_status "Checking pip installation..."
    
    if command -v pip3 &> /dev/null; then
        print_success "pip3 found"
        return 0
    elif command -v pip &> /dev/null; then
        print_success "pip found"
        return 0
    else
        print_error "pip not found. Please install pip."
        return 1
    fi
}

# Create virtual environment
create_venv() {
    print_status "Creating virtual environment..."
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_success "Virtual environment created"
    else
        print_warning "Virtual environment already exists"
    fi
}

# Activate virtual environment
activate_venv() {
    print_status "Activating virtual environment..."
    source venv/bin/activate
    print_success "Virtual environment activated"
}

# Install dependencies
install_dependencies() {
    print_status "Installing Python dependencies..."
    
    # Upgrade pip first
    pip install --upgrade pip
    
    # Install requirements
    pip install -r requirements.txt
    
    print_success "Dependencies installed successfully"
}

# Install the package in development mode
install_package() {
    print_status "Installing GST Analysis System package..."
    
    pip install -e .
    
    print_success "Package installed in development mode"
}

# Create necessary directories
create_directories() {
    print_status "Creating necessary directories..."
    
    mkdir -p data/input
    mkdir -p data/output
    mkdir -p logs
    mkdir -p reports
    
    print_success "Directories created"
}

# Set up configuration
setup_config() {
    print_status "Setting up configuration..."
    
    if [ ! -f "config/settings.yaml" ]; then
        print_warning "Configuration file not found. Please copy config/settings.example.yaml to config/settings.yaml and customize it."
    else
        print_success "Configuration file found"
    fi
}

# Run health check
run_health_check() {
    print_status "Running health check..."
    
    python3 scripts/health_check.py
    
    if [ $? -eq 0 ]; then
        print_success "Health check passed"
    else
        print_warning "Health check failed. Please check the output above."
    fi
}

# Main installation process
main() {
    echo
    print_status "Starting installation process..."
    echo
    
    # Check prerequisites
    if ! check_python; then
        exit 1
    fi
    
    if ! check_pip; then
        exit 1
    fi
    
    # Installation steps
    create_venv
    activate_venv
    install_dependencies
    install_package
    create_directories
    setup_config
    
    echo
    print_success "Installation completed successfully!"
    echo
    
    # Print usage instructions
    echo "📋 Next Steps:"
    echo "=============="
    echo "1. Activate the virtual environment:"
    echo "   source venv/bin/activate"
    echo
    echo "2. Configure the system:"
    echo "   cp config/settings.example.yaml config/settings.yaml"
    echo "   # Edit config/settings.yaml with your settings"
    echo
    echo "3. Place your data files in data/input/"
    echo
    echo "4. Run analysis:"
    echo "   gst-analyze"
    echo
    echo "5. Start web server:"
    echo "   gst-server"
    echo
    echo "6. Access the web interface at:"
    echo "   http://localhost:8000"
    echo
    
    # Run health check
    run_health_check
}

# Run main function
main "$@"
