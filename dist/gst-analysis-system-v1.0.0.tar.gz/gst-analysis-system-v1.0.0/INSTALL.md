# Installation Guide

## Quick Start

### Windows Users
1. Extract the package
2. Double-click `install.bat`
3. Follow the on-screen instructions

### Linux/macOS Users
1. Extract the package
2. Open terminal in the extracted directory
3. Run: `chmod +x install.sh && ./install.sh`

### Docker Users
1. Extract the package
2. Run: `docker-compose up -d`

## Manual Installation

See README.md for detailed manual installation instructions.

## Next Steps

After installation:
1. Place your data files in `data/input/`
2. Configure settings in `config/settings.yaml`
3. Run analysis: `gst-analyze`
4. Start web server: `gst-server`
5. Open http://localhost:8000 in your browser

## Support

- Check README.md for troubleshooting
- Run health check: `python scripts/health_check.py`
