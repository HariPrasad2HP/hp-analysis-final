# Data Directory

## Structure

- `input/`: Place your GST data files here
  - `gst_table_data.xlsx`: Main GST transaction data
  - `sales_records.xlsx`: Sales transaction records
  - `entity_master.xlsx`: Entity master data (optional)

- `output/`: Generated analysis results will be saved here
  - `gst_table_data.json`: Processed GST data
  - `hierarchy_data.json`: Hierarchy analysis results
  - `reports/`: Generated reports

## Data Format

Please refer to the main README.md for detailed data format requirements.
